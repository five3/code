/*-------------------------------------------------------------------------------------------
| File        : FibexReader.h
| Project     : Vector FlexRay Command Line Example
|
| Description : Fibex Converter for Vector XL FlexRay API
|--------------------------------------------------------------------------------------------
| File History:
| Date        Version        Changes
| -----------+--------------+--------------
| 2009-12-17  V1.0.0         Initial version
| 2012-02-23  V1.1.0         Fixed handling of parameters pKeySlotUsedForStartup, pKeySlotUsedForSync, pChannels
|
|--------------------------------------------------------------------------------------------
|--------------------------------------------------------------------------------------------
| Copyright (c) 2012 by Vector Informatik GmbH.  All rights reserved.
|------------------------------------------------------------------------------------------*/

#ifndef _FIBEX_READER_H_
#define _FIBEX_READER_H_

// ---------------------------------------------------------------------------------------------------------------
// INCLUDES
// ---------------------------------------------------------------------------------------------------------------
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#import <msxml6.dll> exclude("ISequentialStream","_FILETIME")  // Should be installed in Windows\System32 folder. Version 6 is the latest.

#include "vxlapi.h" 
// ---------------------------------------------------------------------------------------------------------------


// ---------------------------------------------------------------------------------------------------------------
// PROTOTYPES
// ---------------------------------------------------------------------------------------------------------------
XLstatus FbxRd_LoadFibexConfig(const char* xmlFileName, XLfrClusterConfig &clusterConf);
// ---------------------------------------------------------------------------------------------------------------

#endif //_FIBEX_READER_H_
