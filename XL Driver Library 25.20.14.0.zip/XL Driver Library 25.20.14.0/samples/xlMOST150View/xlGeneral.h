/*-------------------------------------------------------------------------------------------
| File        : xlGeneral.h
| Project     : Vector MOST150 Example 
|
| Description : 
|--------------------------------------------------------------------------------------------
|--------------------------------------------------------------------------------------------
| Copyright (c) 2011 by Vector Informatik GmbH.  All rights reserved.
|------------------------------------------------------------------------------------------*/


#pragma once

class CGeneral
{
public:
  CGeneral(void);
  ~CGeneral(void);
   unsigned short StrToShort(char *str); 
};
