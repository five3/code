﻿using System.Windows;

namespace xlTimeSyncMonitor {
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window {

    public MainWindow() {
      InitializeComponent();
      try {
        DataContext = new MainWindowViewModel();
      } catch (Exception ex) {
        MessageBox.Show("Initialization failed:\n" + ex.Message, "xlTimeSyncMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
        Application.Current.Shutdown();
      }
    }
  }
}