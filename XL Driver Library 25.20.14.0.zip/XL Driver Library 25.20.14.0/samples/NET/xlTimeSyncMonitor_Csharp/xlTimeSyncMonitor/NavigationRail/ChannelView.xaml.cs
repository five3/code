﻿namespace xlTimeSyncMonitor {
  /// <summary>
  /// Interaction logic for ChannelView.xaml
  /// </summary>
  public partial class ChannelView
  {
    public ChannelView()
    {
      InitializeComponent();
    }
  }
}
