﻿namespace xlTimeSyncMonitor {
  /// <summary>
  /// Interaction logic for NetworkView.xaml
  /// </summary>
  public partial class NetworkView
  {
    public NetworkView()
    {
      InitializeComponent();
    }
  }
}
