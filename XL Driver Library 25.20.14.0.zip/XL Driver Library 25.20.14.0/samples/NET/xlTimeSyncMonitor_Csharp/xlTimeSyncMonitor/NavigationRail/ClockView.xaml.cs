﻿namespace xlTimeSyncMonitor {
  /// <summary>
  /// Interaction logic for ClockView.xaml
  /// </summary>
  public partial class ClockView
  {

    public ClockView()
    {
      InitializeComponent();
    }
  }
}
