﻿using System.Collections.ObjectModel;
using System.Reflection.PortableExecutable;
using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles data for a <see cref="ChannelView"/>.
  /// Retrieves and updates information of the given channel based on the channel index.
  /// </summary>
  public class ChannelViewItem : NavigationRailViewItem {
    private readonly Xl xl;
    public int ChannelIndex {  get; private set; }

    private NetworkStatus channelStatus;
    public NetworkStatus ChannelStatus {
      get => channelStatus;
      set => SetProperty(ref channelStatus, value);
    }
    public ChannelViewItem(string Header, int channelIndex) : base(Header, "ServerOutline", new ChannelView()) {
      xl = new Xl();
      channelStatus = new(getStatusResult());
      ChannelIndex = channelIndex;
      Update();
    }

    /// <summary>
    /// Overwritten update function from <see cref="NavigationRailViewItem"/>.
    /// Updates the network status.
    /// </summary>
    public override void Update() {
      ChannelStatus = new(getStatusResult());
    }

    /// <summary>
    /// Calls to the XL API to retirieve the stauts of the channel.
    /// </summary>
    /// <returns>Status information about the channel or an empty status in case of error.</returns>
    private XlTsGetStatusResult getStatusResult() {
      XlTsGetStatusResult status;
      XlPortHandle portHandle = XlPortHandle.Invalid;

      try {
        portHandle = xl.CreatePort("xlTimeSyncMonitor", 256, XlInterfaceVersion.V3, XlBusType.Can);
        xl.AddChannelToPort(portHandle, ChannelIndex, false, XlBusType.Can);
        xl.FinalizePort(portHandle);
        status = xl.TsGetStatus(portHandle, (ulong)ChannelIndex);
      } catch {
        status = new XlTsGetStatusResult {
          TimeScale = new(),
          LeapSeconds = new(),
          GmUuid = new(),
          LocalUuid = new()
        };
      } finally {
        if (portHandle != XlPortHandle.Invalid) {
          xl.ClosePort(portHandle);
        }
      }
      return status;
    }
  }
}
