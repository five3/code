﻿namespace xlTimeSyncMonitor {
  /// <summary>
  /// Interaction logic for NavigationRailView.xaml
  /// </summary>
  public partial class NavigationRailView
  {
    public NavigationRailView()
    {
      InitializeComponent();
    }
  }
}
