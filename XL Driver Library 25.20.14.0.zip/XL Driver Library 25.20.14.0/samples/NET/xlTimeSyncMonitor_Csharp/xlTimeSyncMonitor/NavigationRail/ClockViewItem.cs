﻿using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles data for a <see cref="ClockView"/>.
  /// On startup, creates a new clock on the domain to retrieve domain information.
  /// Runs a update task to update the information every second.
  /// </summary>
  public class ClockViewItem : NavigationRailViewItem {
    private readonly Xl xl;
    private readonly XlTsClockHandle clockHandle;

    private ClockStatus clockStatus;
    public ClockStatus ClockStatus {
      get => clockStatus;
      set => SetProperty(ref clockStatus, value);
    }

    public ClockViewItem(string header) : base(header, "ClockOutline", new ClockView()) {
      xl = new Xl();
      // crate a domain clock and retrieve the domain time
      clockHandle = xl.TsCreateClock(Xl.TsDefaultTimedomainName, XlTsClkExternalType.Domain, XlTsInterfaceVersion.V1);
      try {
        var status = xl.TsGetDomainTime(clockHandle, out var slaveTime);
        clockStatus = new(status, slaveTime);
      } catch {
        clockStatus = new(new(), 0);
      }
      // run update task
      Task.Run(() => UpdateThread());
    }

    ~ClockViewItem() {
      xl.TsDestroyClock(clockHandle);
    }

    /// <summary> 
    /// Update task to update the domain information stored by <see cref="ClockStatus"/> every second.
    /// </summary>
    /// <remarks> Cannot use <see cref="NavigationRailViewItem.Update()"/> becaus this thread runs forever.</remarks>
    public void UpdateThread() {
      while (true) {
        Thread.Sleep(1000);
        try {
          var status = xl.TsGetDomainTime(clockHandle, out var slaveTime);
          ClockStatus = new(status, slaveTime);
        }
        catch {
          ClockStatus = new(new(), 0);
        }
      }
    }
  }
}
