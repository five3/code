﻿using System.Reflection.PortableExecutable;
using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles data for a <see cref="NetworkView"/>.
  /// Retrieves and updates information of the given network based on the network name.
  /// </summary>
  public class NetworkViewItem : NavigationRailViewItem {
    private readonly Xl xl;

    private NetworkStatus networkStatus;
    public NetworkStatus NetworkStatus {
      get => networkStatus;
      set => SetProperty(ref networkStatus, value);
    }
    public NetworkViewItem(string networkName) : base(networkName, "NetworkOutline", new NetworkView()) {
      xl = new Xl();
      networkStatus = new(getStatusResult());
    }

    /// <summary>
    /// Overwritten update function from <see cref="NavigationRailViewItem"/>.
    /// Updates the network status.
    /// </summary>
    public override void Update() {
      NetworkStatus = new(getStatusResult());
    }

    /// <summary>
    /// Calls to the XL API to retirieve the stauts of the newtork.
    /// </summary>
    /// <returns>Status information about the newtork or an empty status in case of error.</returns>
    private XlTsGetStatusResult getStatusResult() {
      XlTsGetStatusResult status;
      XlNetworkHandle networkHandle = XlNetworkHandle.Invalid;
      try {
        networkHandle = xl.NetEthOpenNetwork(Header, "xlTimeSyncMonitor", XlAccessType.Reliable, 8 * 1024 * 1024);
        status = xl.NetTsGetStatus(networkHandle, XlEthPortHandle.Invalid);
      } catch {
        status = new XlTsGetStatusResult {
          TimeScale = new(),
          LeapSeconds = new(),
          GmUuid = new(),
          LocalUuid = new()
        };
      } finally {
        if (networkHandle != XlNetworkHandle.Invalid) {
          xl.NetCloseNetwork(networkHandle);
        }
      }
      return status;
    }
  }
}
