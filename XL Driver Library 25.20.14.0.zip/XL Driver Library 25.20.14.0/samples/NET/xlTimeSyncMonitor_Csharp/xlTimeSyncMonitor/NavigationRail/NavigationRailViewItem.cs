﻿namespace xlTimeSyncMonitor {

  /// <summary>
  /// Base class of an item for a NavigationRail.
  /// </summary>
  public class NavigationRailViewItem : ViewModelBase
  {
    public string Header { get; set; }
    public string Icon { get; set; }
    public object Content { get; set; }

    public NavigationRailViewItem(string header, string icon, object content) {
      Header = header;
      Icon = icon;
      Content = content;
    }

    /// <summary>
    /// Can be used to update the data or view.
    /// </summary>
    public virtual void Update() { }
  }
}
