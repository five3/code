﻿using System.Collections.ObjectModel;
using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles data for <see cref="NavigationRailView"/>.
  /// Gets and updates a list of updating a list of CAN capable devices based on channel access
  /// and creates a <see cref="ChannelViewItem"/> for each.
  /// </summary>
  public class ChannelViewRail : NavigationRailViewItem {
    private readonly Xl xl;
    public ObservableCollection<ChannelViewItem> Tabs { get; set; }

    public ChannelViewRail(string Header) : base(Header, "ServerOutline", new NavigationRailView()) {
      xl = new Xl();
      Tabs = new ObservableCollection<ChannelViewItem>();
      Update();
    }

    /// <summary>
    /// Updates the list of connected devices and calls upon <see cref="ChannelViewItem"/>
    /// to update the dispalyed information
    /// </summary>
    public override void Update() {
      using var driverConfig = xl.CreateDriverConfig();
      var deviceConfig = driverConfig.GetDeviceConfig();
      // create a list of devices
      List<Tuple<string,int>> devices = new List<Tuple<string,int>>();
      foreach (var device in deviceConfig) {
        foreach (var channel in device.channelList) {
          if ((channel.channelBusCapabilities & XlBusType.Can) == XlBusType.Can &&
            device.hwType != XlHwType.Virtual) {
            devices.Add(new($"{device.name}:{device.hwIndex}", channel.channelIndex));
            break;
          }
        }
      }
      // update or remove devices 
      foreach (var tab in Tabs.ToList()) {
        Tuple<string, int> entry = new(tab.Header, tab.ChannelIndex);
        if (devices.Contains(entry)) {
          tab.Update();
          devices.Remove(entry);
        } else { 
          Tabs.Remove(tab);
        }
      }
      // add new devices
      foreach(var device in devices) {
        Tabs.Add(new ChannelViewItem(device.Item1, device.Item2));
      }
    }
  }
}
