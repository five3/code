﻿using System.Collections.ObjectModel;
using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles data for <see cref="NavigationRailView"/>.
  /// Gets and updates a list of configured networks and creates a <see cref="NavigationRailViewItem"/> for each.
  /// </summary>
  public class NetworkViewRail : NavigationRailViewItem {
    private readonly Xl xl;
    public ObservableCollection<NavigationRailViewItem> Tabs { get; set; }

    public NetworkViewRail(string Header) : base(Header, "NetworkOutline", new NavigationRailView()) {
      xl = new Xl();
      Tabs = new ObservableCollection<NavigationRailViewItem>();
      Update();
    }

    /// <summary>
    /// Updates the list of configured networks and calls upon <see cref="NavigationRailViewItem"/>
    /// to update the dispalyed information
    /// </summary>
    public override void Update() {
      // update networkConfig
      using var driverConfig = xl.CreateDriverConfig();
      var networkConfig = driverConfig.GetNetworkConfig();

      List<string> newNetworks = networkConfig.Select(network => network.networkName).ToList();
      // update or remove networks
      foreach (var tab in Tabs.ToList()) {
        if (newNetworks.Contains(tab.Header)) {
          tab.Update();
          newNetworks.Remove(tab.Header);
        } else {
          Tabs.Remove(tab);
        }
      }
      // add new networks
      foreach (var network in newNetworks) {
        Tabs.Add(new NetworkViewItem(network));
      }
    }
  }
}
