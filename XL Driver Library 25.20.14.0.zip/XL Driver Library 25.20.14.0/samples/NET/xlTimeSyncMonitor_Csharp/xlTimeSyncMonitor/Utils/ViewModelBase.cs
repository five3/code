﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace xlTimeSyncMonitor {
  /// <summary>
  /// Basic View Model implementation as used by MVVM
  /// </summary>
  public class ViewModelBase : INotifyPropertyChanged {
    public event PropertyChangedEventHandler? PropertyChanged;

    /// <summary>
    /// Is executed when a property of the view model changes to inform 
    /// subscribers of the change using the <see cref="PropertyChanged"/> event.
    /// </summary>
    /// <param name="propertyName"></param>
    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null) {
      PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    /// <summary>
    /// Shorthand to call the <see cref="OnPropertyChanged"/> function when the
    /// given parameter changes its value.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="member"></param>
    /// <param name="value"></param>
    /// <param name="propertyName"></param>
    /// <returns></returns>
    protected bool SetProperty<T>(ref T member, T value, [CallerMemberName] string? propertyName = null) {
      if (EqualityComparer<T>.Default.Equals(member, value)) {
        return false;
      }

      member = value;
      OnPropertyChanged(propertyName);
      return true;
    }
  }
}

