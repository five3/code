﻿using Vector.XlApi;

namespace xlTimeSyncMonitor {
  /// <summary>
  /// Converts data clases from Vector XlApi into human readable strings
  /// </summary>
  public class Printer {
    /// <summary>
    /// Converts <see cref="XlTsClkUuid"/> into a string.
    /// </summary>
    /// <param name="uuid">UUID that should be converted.</param>
    /// <returns></returns>
    public static string UuidToString(XlTsClkUuid uuid) {
      switch (uuid.uuidFormat) {
        default:
          return uuid.uuidFormat.ToString();
        case XlTsClockUuidFormat.VectorDev:
          return $"Article: {uuid.uuid_vectorDevUuid_articleNumber} Serial: {uuid.uuid_vectorDevUuid_serialNumber} ClockId: {uuid.uuid_vectorDevUuid_clkId}";
        case XlTsClockUuidFormat.Eui64:
          return string.Join("-", uuid.uuid_eui64Uuid_oui.Concat(uuid.uuid_eui64Uuid_extensionId).Select(b => b.ToString("X2")).ToArray());
      }
    }
    /// <summary>
    /// Converts <see cref="XlTsLeapSeconds"/> into a string.
    /// </summary>
    /// <param name="leapSeconds">Leap seconds that should be converted.</param>
    /// <returns></returns>
    public static string LeapSecondsToString(XlTsLeapSeconds leapSeconds) {
      return (leapSeconds.leapSecondsFlags == XlTsLeapSecondsFlags.Valid) ? $"Valid: {leapSeconds.leapSecondsValue} seconds" : "Invalid";
    }

    /// <summary>
    /// Converts nanoseconds into a string representing a time span.
    /// </summary>
    /// <param name="nanoSeconds">Nanoseconds that should be converted.</param>
    /// <returns></returns>
    public static string NanoSecondsToString(ulong nanoSeconds) {
      return TimeSpan.FromTicks((long)nanoSeconds / 100).ToString(@"d'd 'hh'h 'mm'm 'ss'.'fffffff's'");
    }

    /// <summary>
    /// Converts nanoseconds into a string representing a date.
    /// </summary>
    /// <param name="nanoSeconds">Nanoseconds that should be converted.</param>
    /// <returns></returns>
    public static string DateToString(ulong nanoSeconds) {
      var epochTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
      return epochTime.AddTicks((long)nanoSeconds / 100).ToString(@"MM\/dd\/yyyy HH:mm:ss.fffffff");
    }
  }

  /// <summary>
  /// Data class that gives access to the members of <see cref="XlTsGetStatusResult"/> as string.
  /// </summary>
  /// <param name="status">Result from a <see cref="Xl.TsGetStatus(XlPortHandle, ulong)"/> or 
  /// <see cref="Xl.NetTsGetStatus(XlNetworkHandle, XlEthPortHandle)"/> call.</param>
  public class NetworkStatus {
    public XlTsGetStatusResult Status { get; set; }
    public string TimeScale { get { return Status.TimeScale.ToString(); } set { } }
    public string LeapSeconds {
      get { return Printer.LeapSecondsToString(Status.LeapSeconds); }
      set { }
    }
    public string LocalUuid {
      get { return Printer.UuidToString(Status.LocalUuid); }
      set { }
    }
    public string GmUuid {
      get { return Printer.UuidToString(Status.GmUuid); }
      set { }
    }
    public string SyncStatus {
      get { return (Status.TimeScale == XlTsTimeScale.Undefined) ? "NotInSync" : "InSync"; }
      set { }
    }
    public NetworkStatus(XlTsGetStatusResult status) {
      Status = status;
    }
  }

  /// <summary>
  /// Data class that gives access to the members of <see cref="XlTsDomainTime"/> as string.
  /// </summary>
  /// <param name="status">Result from a call to <see cref="Xl.TsGetDomainTime(XlTsClockHandle, out ulong)"/.></param>
  /// <param name="slaveTime">Slavetime from a call to <see cref="Xl.TsGetDomainTime(XlTsClockHandle, out ulong)"</param>
  public class ClockStatus {
    public XlTsDomainTime Status { get; set; }
    public ulong SlaveTime { get; set; }
    public string StringSlaveTime { get { return Printer.NanoSecondsToString(SlaveTime); } set { } }
    public string DomainTime {
      get {
        return Status.timeScale switch {
          XlTsTimeScale.Tai or XlTsTimeScale.Utc or XlTsTimeScale.Rtc => Printer.DateToString(Status.domainTime),
          _ => Printer.NanoSecondsToString(Status.domainTime),
        };
      }
      set { }
    }
    public string TimeScale { get { return Status.timeScale.ToString(); } set { } }
    public string LeapSeconds {
      get { return Printer.LeapSecondsToString(new(Status.leapSeconds)); }
      set { }
    }
    public string SyncStatus {
      get { return (Status.syncStatus != 0) ? Status.syncStatus.ToString() : "NotInSync"; }
      set { }
    }
    public string ClusterMaster {
      get { return Printer.UuidToString(new(Status.clusterMaster)); }
      set { }
    }
    public ClockStatus(XlTsDomainTime status, ulong slaveTime) {
      Status = status;
      SlaveTime = slaveTime;
    }
  }
}
