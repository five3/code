﻿using System.Collections.ObjectModel;
using Vector.XlApi;

namespace xlTimeSyncMonitor {

  /// <summary>
  /// Handles the data for the main window.
  /// </summary>
  public class MainWindowViewModel : ViewModelBase {
    private readonly Xl xl;
    private readonly XlPortHandle statusPort;
    private readonly AutoResetEvent notificationEvent;
    public ObservableCollection<NavigationRailViewItem> Tabs { get; set; }

    public MainWindowViewModel() {
      
      // populate NavigationRail
      Tabs = new ObservableCollection<NavigationRailViewItem> {
        new ClockViewItem("Application Clock"),
        new ChannelViewRail("Devices"), 
        new NetworkViewRail("Networks")
      };

      // create a notification event to be informed about updates
      xl = new Xl();
      statusPort = xl.CreatePort("xlTimeSyncMonitor", 0, XlInterfaceVersion.V4, XlBusType.Status);
      xl.FinalizePort(statusPort);
      notificationEvent = xl.NetTsSetNotification(statusPort, XlNetworkHandle.Invalid);
      
      // run update task
      Task.Run(() => Update());
    }

    ~MainWindowViewModel() {
      xl.ClosePort(statusPort);
    }

    /// <summary>
    /// Update task. This waits for a notification event from the
    /// Vector TimeSyncService and triggers updating the tabs.
    /// </summary>
    public void Update() {
      while (true) {
        notificationEvent.WaitOne();
        foreach (var tab in Tabs) {
          // UI updates can only be done by UI thread.
          App.Current.Dispatcher.Invoke(() => tab.Update());
        }
      }
    }
  }
}

