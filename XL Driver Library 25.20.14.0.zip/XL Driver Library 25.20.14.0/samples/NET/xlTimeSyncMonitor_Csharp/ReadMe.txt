--------------------------------------------------------------------------------

                          xlTimeSyncMonitor_Csharp

                      Vector Informatik GmbH, Stuttgart

--------------------------------------------------------------------------------

Vector Informatik GmbH
Ingersheimer Stra�e 24
70499 Stuttgart, Germany

Phone: ++49 - 711 - 80670 - 0
Fax:   ++49 - 711 - 80670 - 111


--------------------------------------------------------------------------------

xlTimeSyncMonitor_Csharp is a demo application for the time synchronization
functionality of Vector hardware devices. The demo is programmed in the C# and 
uses WPF and the Vector XLAPI.
 
For further information look into the 'XL Driver Library - Description.pdf' 
document.

Needs Vector DriverPackage >= V25.20

--------------------------------------------------------------------------------

Function:

The xlTimeSyncMonitor_Csharp displays information about the clocks of the 
connected devices and configured networks.

Note: A device is only listed when it has at least one CAN channel, which should
be most of the Vector devices. However, the code can also be modified to list
devices using other channels.