﻿/*-------------------------------------------------------------------------------------------
| File        : Program.cs
| Project     : Vector Ethernet Network-Based Mode .NET Example
|
| Description : Demonstrates use of the Network-based Ethernet functionality of Vector.XlApi.
|--------------------------------------------------------------------------------------------
| Copyright (c) 2020 by Vector Informatik GmbH.  All rights reserved.
|-------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using Vector.XlApi;

namespace xlNetEthDemo_Csharp {
  /// <summary>This helper class combines the common properties of connected measurement points and opened virtual ports.</summary>
  class MpOrVp {
    /// <summary>The represented measurement point or null if the object does not represent a MP.</summary>
    public XlImeasurementPointDrvConfig Mp { get; set; }

    /// <summary>The represented virtual port or null if the object does not represent a VP.</summary>
    public XlIvirtualPortDrvConfig Vp { get; set; }

    /// <summary>XLAPI assigned handle that identifies the MP or VP in function calls.</summary>
    public XlEthPortHandle PortHandle { get; set; }

    /// <summary>Application assigned handle that identifies the MP or VP in XLAPI events.</summary>
    public XlRxHandle RxHandle { get; set; }

    /// <summary>The name of this Mp or VP. </summary>
    public string Name {
      get => !(Mp is null) ? Mp.measurementPointName : (!(Vp is null) ? Vp.virtualPortName : null);
    }
  }

  /// <summary>Combines a network with its index in the XlIdriverConfig (the "ID" in the tables).</summary>
  class NetworkWithIndex {
    public static IEnumerable<NetworkWithIndex> Enumerate(IEnumerable<XlInetworkDrvConfig> networkConfigs) {
      return networkConfigs.Select((netCfg, idx) => new NetworkWithIndex { NetworkConfig = netCfg, Index = idx });
    }

    /// <summary>Configuration of network at index.</summary>
    public XlInetworkDrvConfig NetworkConfig { get; set; }

    /// <summary>Index of the network ("ID").</summary>
    public int Index { get; set; }
  } 

  /// <summary>The demo program.</summary>
  class Program {
    // --------------------------------------------------------------------------------------
    // Constants
    // --------------------------------------------------------------------------------------
    /// <summary>Name of the virtual port that this demo adds to a user-selectable segment.</summary>
    static string AddVpName = "VP_manually_added";

    /// <summary>Size of the EtherType field in number of bytes.</summary>
    const int EtherTypeSize = 2;

    /// <summary>Size of the IPv4 header without options in number of bytes.</summary>
    const int IpV4HeaderSize = 20;

    /// <summary>Size of a UDP header in number of bytes.</summary>
    const int UdpHeaderSize = 8;

    /// <summary>UDP Source port that the demo writes in transmitted frames.</summary>
    const ushort UdpSourcePort = 65281;

    /// <summary>UDP destination port that the demo writes in transmitted frames.</summary>
    const ushort UdpRemotePort = 65282;

    /// <summary>Source IP address that the demo writes in transmitted frames, except for the LSB, which the demo replaces with the RxHandle of the port.</summary>
    static IPAddress SourceIP = IPAddress.Parse("192.168.0.0");

    /// <summary>Message that the demo writes in transmitted frames.</summary>
    string PayloadMessage = "Vector Informatik GmbH : Network-based mode C# Ethernet Example";

    /// <summary>The EtherType of IPv4 is 0x0800. As the EtherType field is in network-byte order, the constant is byte-reversed.</summary>
    const ushort EthertypeIpV4Be = 0x0008;

    /// <summary>The first byte of the IPv4 header.</summary>
    const byte IpV4VersionIhlField = 0x40 | (IpV4HeaderSize / 4);

    /// <summary>Value if the IPv4 Protocol field for UDP.</summary>
    const byte IpProtocolUdp = 17;

    // --------------------------------------------------------------------------------------
    // Member variables - the following variables are practically global, as this demo
    // creates a single 'Program' object.
    // --------------------------------------------------------------------------------------
    /// <summary>List of devices found at start of demo.</summary>
    IReadOnlyList<XlIdeviceDrvConfig> _devices = null;

    /// <summary>List of networks found at start of demo.</summary>
    List<NetworkWithIndex> _networks = null;

    /// <summary>Information on the network opened by this application.</summary>
    NetworkWithIndex _selectedNetwork = null;

    /// <summary>Information on the segment that the user selected to add a VP on.</summary>
    XlIswitchDrvConfig _segmentToAddVpOn = null;

    /// <summary>Handle for the network opened by this application.</summary>
    XlNetworkHandle _networkHandle = XlNetworkHandle.Invalid;

    /// <summary>List of all connected measurement points.</summary>
    List<MpOrVp> _connectedMPs = new List<MpOrVp>();

    /// <summary>List of all open virtual ports.</summary>
    List<MpOrVp> _openVPs = new List<MpOrVp>();

    /// <summary>Mapping from XlRxHandle to MpOrVp for quick lookup in XLAPI event processing.</summary>
    Dictionary<XlRxHandle, MpOrVp> _rxHandleMap = new Dictionary<XlRxHandle, MpOrVp>();

    /// <summary>Index of the currently selected MP in _connectedMPs or -1 if no MP is selected.</summary>
    int _currentMpIdx = -1;

    /// <summary>Index of the currently selected VP in _openVPs or -1 if no VP is selected.</summary>
    int _currentVpIdx = -1;

    /// <summary>Notification event signaled when the driver adds new XLAPI events to the receive queue.</summary>
    AutoResetEvent _notifyEvent = null;

    /// <summary>True if the network is active.</summary>
    bool _networkActivated = false;

    /// <summary>Buffer to hold the last received frame instead of allocating new memory on every received frame.</summary>
    XlNetEthDataframeRx _lastRxFrameReceived = new XlNetEthDataframeRx();

    /// <summary>User selectable destination Mac address.</summary>
    XlEthMacAddress _remoteMac = XlEthMacAddress.Boradcast;

    /// <summary>Source Mac address requested from network or <c>null</c> if no Mac was reserved.</summary>
    XlEthMacAddress _sourceMac = null;

    /// <summary>User selectable destination IP Address.</summary>
    IPAddress _remoteIp = IPAddress.Parse("192.168.255.255");

    // --------------------------------------------------------------------------------------
    // Static helper methods
    // --------------------------------------------------------------------------------------

    /// <summary>Pad a string left and right to print it centered</summary>
    static string PadCenter(string str, int width) {
      if (width <= str.Length) {
        return str;
      }
      int leftPadding = str.Length + (width - str.Length) / 2;
      return str.PadLeft(leftPadding).PadRight(width);
    }

    /// <summary>Explain that the demo needs a network and ask the user to press enter.</summary>
    static void AbortDemoDueToMissingNetwork() {
      Console.WriteLine("Found 0 ethernet networks. Please ensure that a device operating in network-based mode is connected");
      Console.WriteLine("and use Vector Hardware Configuration to configure a network on that device.");
      Console.WriteLine("Press any key to quit.");
      Console.ReadKey(true);
    }

    /// <summary>Explain that the demo failed to open a virtual port or measurement point.</summary>
    static void AbortDemoDueToMissingPorts() {
      Console.WriteLine("No virtual ports could be added or opened and no measurement point was connected.");
      Console.WriteLine("Please check the network configuration.");
      Console.WriteLine("Press any key to quit.");
      Console.ReadKey(true);
    }

    /// <summary>Print a table of all switches in a given set of ethernet networks.</summary>
    static void ShowNetworks(IEnumerable<NetworkWithIndex> networksWithIndex) {
      Console.WriteLine("+----------------------------------------------------------------------------------------------------------+");
      Console.WriteLine("|                                            Network Configuration                                         |");
      Console.WriteLine("+----+---------------------------------+-------+---------------------------------+-----------+------+------+");
      Console.WriteLine("| ID |              Name               | SegId |             SegName             |    Type   | #MPs | #VPs |");
      Console.WriteLine("+----+---------------------------------+-------+---------------------------------+-----------+------+------+");

      foreach (var networkWithIndex in networksWithIndex) {
        var network = networkWithIndex.NetworkConfig;
        if (network.networkType == XlNetworkType.Eth) {
          foreach (var segment in network.switchList) {
            Console.WriteLine($"|{networkWithIndex.Index,4}|{PadCenter(network.networkName, 33)}|{segment.switchId,7}|" +
                              $"{PadCenter(segment.switchName, 33)}|{segment.switchCapability,11}|" +
                              $"{segment.mpList.Count,6}|{segment.vpList.Count,6}|");
          }
        }
      }
      Console.WriteLine("+----------------------------------------------------------------------------------------------------------+");
    }

    /// <summary>Format the bus params of a channel to produce a string for the LinkState column of ShowDriverConfig</summary>
    static string GetLinkStateString(XlBusParams busParams) {
      if (busParams.data_ethernet_link == XlEthStatusLink.Up) {
        switch (busParams.data_ethernet_phy) {
          case XlEthStatusPhy.PhyIeee8023:
            switch (busParams.data_ethernet_speed) {
              case XlEthStatusSpeed.Speed10: return "Up IEEE 10 MBit/s";
              case XlEthStatusSpeed.Speed100: return "Up IEEE 100 MBit/s";
              case XlEthStatusSpeed.Speed1000: return "Up IEEE 1 GBit/s";
              default: return $"Up IEEE {busParams.data_ethernet_speed}";
            }
          case XlEthStatusPhy.Phy100baseT1:
            return $"Up 100BASE-T1 {busParams.data_ethernet_clockMode}";
          case XlEthStatusPhy.Phy1000baseT1:
            return $"Up 1000BASE-T1 {busParams.data_ethernet_clockMode}";
          default:
            return $"Up {busParams.data_ethernet_phy}";
        }
      } else {
        return $"{busParams.data_ethernet_link}";
      }
    }

    // --------------------------------------------------------------------------------------
    // Methods
    // --------------------------------------------------------------------------------------

    /// <summary>Print some configuration information. It is called before the MainLoop starts.</summary>
    void ShowSettings() {
      Console.WriteLine("Default settings:");
      Console.WriteLine($"- Port index: {_currentMpIdx}");
      Console.WriteLine($"- Remote MAC address: {_remoteMac}");
      Console.WriteLine($"- Remote IP address: {_remoteIp}");
    }

    /// <summary>Print tables for the selected network and the devices that participate in this network.</summary>
    void ShowDriverConfig() {
      using (var driverConfig = new Xl().CreateDriverConfig()) {
        foreach (var device in driverConfig.GetDeviceConfig()) {
          // Only print devices that participate in the network
          if (_selectedNetwork.NetworkConfig.switchList.Any((segment) => 
              segment.device.hwType == device.hwType && segment.device.hwIndex == device.hwIndex)) {

            Console.WriteLine("+-----------------------------------------------------------------------------------+");
            Console.WriteLine($"| {device.name,-7} : {device.hwIndex+1,2} ({device.serialNumber:D6})" +
                               "          Hardware Configuration                             |");
            Console.WriteLine("+------+------+-------------------------+------------------+------------------------+");
            Console.WriteLine("| HwNr | HwCh |    Transceiver          | MAC              | LinkState              |");
            Console.WriteLine("+------+------+-------------------------+------------------+------------------------+");
            foreach (var channel in device.channelList) {
              if (channel.busParams.busType == XlBusType.Ethernet) {
                // strip the "On board " prefix from the transceiver name to save a bit of space in the table.
                Console.WriteLine($"| {device.hwIndex,4} | {channel.hwChannel,4} |" +
                                  $" {channel.transceiver.name.Replace("On board ", ""),-24}|" +
                                  $" {channel.busParams.data_ethernet_macAddr}|" +
                                  $" {$"{GetLinkStateString(channel.busParams)}",-23}|");
              }
            }
          }
        }
        
        // read the updated network configuration and lookup the selected network.
        var networks = NetworkWithIndex.Enumerate(driverConfig.GetNetworkConfig());
        ShowNetworks(networks.Where((n) => n.NetworkConfig.networkName == _selectedNetwork.NetworkConfig.networkName));
      }
    }

    static string ClockUuidToString(XlTsClkUuid uuid) {
      switch (uuid.uuidFormat) {
        case XlTsClockUuidFormat.Undefined:
          return "Undefined";
        case XlTsClockUuidFormat.VectorDev:
          return $"article: {uuid.uuid_vectorDevUuid_articleNumber} serial: {uuid.uuid_vectorDevUuid_serialNumber} clockId: {uuid.uuid_vectorDevUuid_clkId}";
        case XlTsClockUuidFormat.Eui64:
          StringBuilder stream = new StringBuilder();
          foreach (byte c in uuid.uuid_eui64Uuid_oui) {
            stream.AppendFormat("{0:x2}::", c);
          }
          foreach (byte c in uuid.uuid_eui64Uuid_extensionId) {
            stream.AppendFormat("{0:x2}::", c);
          }
          return stream.ToString().Substring(0, stream.Length - 2);
        case XlTsClockUuidFormat.LocalPc:
          return "Local PC";
        case XlTsClockUuidFormat.VectorPc:
          return "Vector PC";
        case XlTsClockUuidFormat.StandardPc:
        case XlTsClockUuidFormat.PerformanceCnt:
          return "Performance Counter";
        case XlTsClockUuidFormat.External:
          return "External";
      }
      return "Unknown";
    }

    /// <summary>Reset clocks on network</summary>
    void HandleResetClocks() {
      try { 
        ulong timeOffset = 0;
        var result = new Xl().NetTsResetClocks(_networkHandle, ref timeOffset);

        Console.WriteLine("Reset clocks on network:");
        Console.WriteLine($"  Cluster master: {ClockUuidToString(result.GmUuid)}");
        Console.WriteLine($"  Time scale: {result.TimeScale}");
        Console.WriteLine($"  Leap seconds: flags={result.LeapSeconds.leapSecondsFlags} value={result.LeapSeconds.leapSecondsValue}");
        Console.WriteLine($"  TimeOffset: {timeOffset}");
        Console.WriteLine("");
      } catch (XlException ex) {
        Console.WriteLine($"ERROR: Reset clocks failed with {ex}");
      }
    }

    /// <summary>Ask the user to select a network by network ID and check if the network is correctly configured.</summary>
    NetworkWithIndex ChooseNetwork() {
      Console.Write("Choose Network to connect to: ");
      while (true) {
        var keyInfo = Console.ReadKey(true);
        if (keyInfo.Key == ConsoleKey.Escape) {
          return null;
        } else if (keyInfo.KeyChar >= '0' && keyInfo.KeyChar <= '9') {
          // Lookup network by index
          var netWithIdx = _networks.SingleOrDefault((n) => n.Index == keyInfo.KeyChar - '0');
          if (!(netWithIdx is null)) {
            // Check if demo can open this network.
            var network = netWithIdx.NetworkConfig;
            if (network.networkType == XlNetworkType.Eth && network.statusCode == XlNetCfgStat.Ok) {
              Console.WriteLine($"Selected network {network.networkName}.");
              return netWithIdx;
            } else if (network.networkType != XlNetworkType.Eth) {
              Console.WriteLine($"Cannot select {network.networkName} because it is not an ethernet network.");
            } else {
              Console.WriteLine($"Cannot select {network.networkName} because of configuration error: {network.statusErrorString}");
            }
          }
        }
        Console.WriteLine($"Enter a network ID in range 0..{_networks.Count - 1} or ESC to abort.");
      }
    }

    /// <summary>Ask the user to select a segment to which a VP will be added.</summary>
    XlIswitchDrvConfig ChooseSegmentForAddVp() {
      Console.Write("Choose Segment to manually attach VP: ");
      while (true) {
        var keyInfo = Console.ReadKey(true);
        if (keyInfo.Key == ConsoleKey.Escape) {
          return null;
        } else if (keyInfo.KeyChar >= '0' && keyInfo.KeyChar <= '9') {
          // Lookup segment by switchId.
          var segment = _selectedNetwork.NetworkConfig.switchList.SingleOrDefault((s) => s.switchId == (XlSwitchId)(keyInfo.KeyChar - '0'));
          if (!(segment is null)) {
            // Check if this segment can accommodate another VP.
            if (segment.switchCapability == XlNetEthSwitchCap.TapLink) {
              Console.WriteLine("Virtual ports cannot be added to Taps.");
            } else if (segment.switchCapability == XlNetEthSwitchCap.Directconn && segment.vpList.Count > 0) {
              Console.WriteLine("The selected Tap already has a VP attached.");
            } else {
              Console.WriteLine($"Selected segment {segment.switchName}.");
              return segment;
            }
          }
        }
        Console.WriteLine("Enter one of the segIDs above or ESC to skip this step.");
      }
    }

    /// <summary>Insert a connected MP in the data structures of this demo.</summary>
    void InsertConnectedMp(XlImeasurementPointDrvConfig mpConfig, XlEthPortHandle mpHandle, XlRxHandle rxHandle) {
      var mp = new MpOrVp { Mp = mpConfig, PortHandle = mpHandle, RxHandle = rxHandle };
      _connectedMPs.Add(mp);
      _rxHandleMap.Add(rxHandle, mp);
      if (_currentMpIdx == -1) {
        _currentMpIdx = _connectedMPs.Count() - 1;
      }
    }

    /// <summary>Insert an open VP in the data structures of this demo.</summary>
    void InsertOpenVp(XlIvirtualPortDrvConfig vpConfig, XlEthPortHandle vpHandle, XlRxHandle rxHandle) {
      var vp = new MpOrVp { Vp = vpConfig, PortHandle = vpHandle, RxHandle = rxHandle };
      _openVPs.Add(vp);
      _rxHandleMap.Add(rxHandle, vp);
      if (_currentVpIdx == -1) {
        _currentVpIdx = _openVPs.Count() - 1;
      }
    }

    /// <summary>Add ports to the network.</summary>
    void AddOpenOrConnectVPandMP() {
      // Additional Xl objects may be allocated wherever it is convenient.
      var xl = new Xl();

      // For simplicity, assign XlRxHandles sequentially, starting with 1.
      XlRxHandle nextRxHandle = (XlRxHandle)1;

      // If the user selected a segment for adding a VP, add it now.
      if (!(_segmentToAddVpOn is null)) {
        try {
          XlEthPortHandle vpHandle = xl.NetAddVirtualPort(_networkHandle, _segmentToAddVpOn.switchName, AddVpName, nextRxHandle);
          // After adding a VP, it becomes part of the driver config. To show this, the demo creates a new driver config instance
          // and looks up the new VP. The demo also checks the switchId and network name, just in case that the config contains
          // a second VP with the same name in another network.
          XlIvirtualPortDrvConfig vpConfig;
          using (var driverConfig = xl.CreateDriverConfig()) {
            vpConfig = driverConfig.GetVirtualPortConfig().Single((vp) =>
              vp.virtualPortName == AddVpName &&
              vp.switchId == _segmentToAddVpOn.switchId &&
              driverConfig.GetNetworkConfig()[vp.networkIdx].networkName == _selectedNetwork.NetworkConfig.networkName);
          };
          InsertOpenVp(vpConfig, vpHandle, nextRxHandle);
          nextRxHandle++;
          Console.WriteLine("INFO : VP successfully manually added");
        } catch (XlException ex) {
          Console.WriteLine($"ERROR: Failed to open VP \"{AddVpName}\" to segment \"{_segmentToAddVpOn.switchName}\"");
          Console.WriteLine(ex);
        }
      }

      // For demo purposes, try to open every pre-configured VP in the network. Note that this reads the _networkConfig.switchList
      // from the first call of CreateDriverConfig(). Opening the VP that was just added would fail, because it is already opened.
      foreach (var segmentConfig in _selectedNetwork.NetworkConfig.switchList) {
        foreach (var vpConfig in segmentConfig.vpList) {
          try {
            XlEthPortHandle vpHandle = xl.NetOpenVirtualPort(_networkHandle, vpConfig.virtualPortName, nextRxHandle);
            InsertOpenVp(vpConfig, vpHandle, nextRxHandle);
            nextRxHandle++;
          } catch (XlException ex) {
            Console.WriteLine($"ERROR: Failed to open VP \"{vpConfig.virtualPortName}\"");
            Console.WriteLine(ex);
          }
        }
      }

      // For demo purposes, try to connect every MP in the network.
      foreach (var segmentConfig in _selectedNetwork.NetworkConfig.switchList) {
        foreach (var mpConfig in segmentConfig.mpList) {
          try {
            XlEthPortHandle mpHandle = xl.NetConnectMeasurementPoint(_networkHandle, mpConfig.measurementPointName, nextRxHandle);
            InsertConnectedMp(mpConfig, mpHandle, nextRxHandle);
            nextRxHandle++;
          } catch (XlException ex) {
            Console.WriteLine($"ERROR: Failed to connect MP \"{mpConfig.measurementPointName}\"");
            Console.WriteLine(ex);
          }
        }
      }
    }

    /// <summary>Calculate the IPv4 checksum as the 16-bit one's complement of the one's complement sum of all 16 bit words in the header.</summary>
    ushort CalculateIPv4HeaderChecksum(XlArraySliceByte payload) {
      uint wordSum = 0;
      for (int octet = 0; octet < IpV4HeaderSize; octet += 2) {
        wordSum += payload.ReadUInt16Be(octet);
      }
      return (ushort)(~((wordSum >> 16) + (wordSum & 0xffff)));
    }

    /// <summary>Write an IPv4 header and a UDP header.</summary>
    void FrameAddIpV4UdpHeader(XlEthDataframeTx frame, IPAddress sourceIp) {
      var payload = frame.frameData_ethFrame_payload;
      // Write the IPv4 header. Note that this code assumes that payload is zero-filled.
      payload[0] = IpV4VersionIhlField;
      payload.WriteUInt16Be(2, (ushort)(frame.dataLen - EtherTypeSize));
      payload[9] = IpProtocolUdp;
      payload.CopyFrom(sourceIp.GetAddressBytes(), 0, 12, 4);
      payload.CopyFrom(_remoteIp.GetAddressBytes(), 0, 16, 4);
      payload.WriteUInt16Be(10, CalculateIPv4HeaderChecksum(payload));

      // Write the UDP header.
      payload.WriteUInt16Be(20, UdpSourcePort);
      payload.WriteUInt16Be(22, UdpRemotePort);
      payload.WriteUInt16Be(24, (ushort)(frame.dataLen - EtherTypeSize - IpV4HeaderSize));
      // UDP checksum remains zero.
    }

    /// <summary>Send a single ethernet frame with a IPv4 Header, a UDP header and a string as payload.</summary>
    void SendSingleFrame(MpOrVp portToSendOn) {
      // Our UDP-Payload is the UTF-8 encoded string message.
      var payload = Encoding.UTF8.GetBytes(PayloadMessage);
      // Allocate a new, zero filled DataframeTx.
      var frame = new XlEthDataframeTx();

      // -----  FRAME LENGTH ------
      // Ensure the frame has at least the minimum length. +1 reserves a byte for the null-termination of the string.
      int dataLen = Math.Max(checked(EtherTypeSize + IpV4HeaderSize + UdpHeaderSize + payload.Length + 1), (int)(Xl.EthPayloadSizeMin + EtherTypeSize));
      if (dataLen > Xl.EthPayloadSizeMax) {
        throw new InvalidOperationException($"dataLen={dataLen} > {Xl.EthPayloadSizeMax}");
      }

      frame.dataLen = (ushort)dataLen;
      Console.WriteLine($"Data {payload.Length} (total {frame.dataLen}) sending on {(portToSendOn.Mp is null ? "VP" : "MP")} {portToSendOn.Name}");

      // -----  MAC ADDRESS CONFIG ------
      // The UseSourceMac flag must be set to transmit in network-based mode.
      frame.flags |= XlEthDataframeFlags.UseSourceMac;
      if (_sourceMac is null) {
        // If the user did not acquire a unique MAC for sending, the demo tries to emulate the behavior without UseSourceMac, by reading the MAC
        // address that is assigned to the channel. This on only possible on MPs as VPs are not associated to a channel. Note that on the recent
        // devices, like the VN5620, which only support the network based mode, the MAC address of automotive ethernet channels is zero.
        var busParams = portToSendOn.Mp?.channel?.busParams;
        if (!(busParams is null) && busParams.busType == XlBusType.Ethernet) {
          frame.sourceMAC = busParams.data_ethernet_macAddr;
        }
      } else {
        frame.sourceMAC = _sourceMac;
      }
      frame.destMAC = _remoteMac;
      frame.frameData_ethFrame_etherType = EthertypeIpV4Be;

      // -----  IPv4 / UDP HEADER ------
      // Write a simple IPv4 and UDP header at the start of the frame. The LSB of the SourceIP is set to the RxHandle of the sending port.
      var ipBytes = SourceIP.GetAddressBytes();
      ipBytes[3] = (byte)portToSendOn.RxHandle;
      FrameAddIpV4UdpHeader(frame, new IPAddress(ipBytes));

      // -----  ADD DATA PAYLOAD ------
      frame.frameData_ethFrame_payload.CopyFrom(payload, 0, IpV4HeaderSize + UdpHeaderSize, payload.Length);

      // -----  SEND ON MP/VP PORT ------
      new Xl().NetEthSend(_networkHandle, portToSendOn.PortHandle, 0, frame);
    }

    /// <summary>Print the demos help menu.</summary>
    void ShowMenuHelp() {
      int maxMp = Math.Min(_connectedMPs.Count, 9);
      Console.WriteLine();
      Console.WriteLine("-------------------------------------------------------------");
      Console.WriteLine("-               xlEthNetDemo_Csharp - HELP                  -");
      Console.WriteLine("-------------------------------------------------------------");
      Console.WriteLine("- Keyboard commands:                                        -");
      if (_connectedMPs.Count > 1) {
        Console.WriteLine($"- '1'..'{maxMp}' Select Ethernet port          [MP]               -");
        Console.WriteLine("- '+'      Select next Ethernet port     [MP]               -");
        Console.WriteLine("- '-'      Select previous Ethernet port [MP]               -");
      }
      Console.WriteLine("- 't'      Transmit single packet        [MP]               -");
      Console.WriteLine("- '*'      Select next Ethernet port     [VP]               -");
      Console.WriteLine("- '/'      Select previous Ethernet port [VP]               -");
      Console.WriteLine("- 'T'      Transmit single packet        [VP]               -");
      Console.WriteLine("- 's'      Current port link status                         -");
      Console.WriteLine("- 'p'      Print INFO of last received Eth message          -");
      Console.WriteLine("- 'G'      Request new MAC address                          -");
      Console.WriteLine("- 'R'      Release taken MAC address                        -");
      Console.WriteLine("- 'm'      Set receiver MAC address                         -");
      Console.WriteLine("- 'i'      Set receiver IP  address                         -");
      Console.WriteLine("- 'w'      Show driver configuration                        -");
      Console.WriteLine("- 'r'      Reset clocks on network                          -");
      Console.WriteLine("- 'h'      Help                                             -");
      Console.WriteLine("- 'q'      Quit                                             -");
      Console.WriteLine("-------------------------------------------------------------");
      Console.WriteLine();
    }

    /// <summary>Directly select a measurement point by index.</summary>
    void HandleSelectMp(int mpIdx) {
      if (mpIdx < _connectedMPs.Count) {
        _currentMpIdx = mpIdx;
        Console.WriteLine($"Selected MP ({mpIdx + 1}) \"{_connectedMPs[mpIdx].Name}\"");
      } else {
        Console.WriteLine(($"Unknown MP in the network. Max MP #{_connectedMPs.Count}"));
      }
    }

    /// <summary>Select the previous or next measurement point.</summary>
    /// <param name="offset">-1 for the previous or +1 for the next MP.</param>
    void HandlePrevNextMp(int offset) {
      if (_connectedMPs.Count > 0) {
        _currentMpIdx = (_connectedMPs.Count + _currentMpIdx + offset) % _connectedMPs.Count;
        Console.WriteLine($"Selected MP ({_currentMpIdx + 1}) \"{_connectedMPs[_currentMpIdx].Name}\"");
      } else {
        Console.WriteLine("No connected MPs available");
      }
    }

    /// <summary>Select the previous or next virtual port. </summary>
    /// <param name="offset">-1 for the previous or +1 for the next VP.</param>
    void HandlePrevNextVp(int offset) {
      if (_openVPs.Count > 0) {
        _currentVpIdx = (_openVPs.Count + _currentVpIdx + offset) % _openVPs.Count;
        Console.WriteLine($"Selected VP ({_currentVpIdx + 1}) \"{_openVPs[_currentVpIdx].Name}\"");
      } else {
        Console.WriteLine("No open VPs available");
      }
    }

    /// <summary>Request a <see cref="XlEthChannelStatus"/> event from every open measurement point in the network.</summary>
    void HandleRequestChannelStatus() {
      new Xl().NetEthRequestChannelStatus(_networkHandle);
    }

    /// <summary>Reserve a globally unique MAC address from the network.</summary>
    void HandleRequestSourceMacAddress() {
      if (_sourceMac is null) {
        var status = new Xl().TryNetRequestMACAddress(_networkHandle, out _sourceMac);
        if (status == XlStatus.Success) {
          Console.WriteLine($"New Src MAC Address : {_sourceMac}");
        } else {
          Console.WriteLine($"ERROR : Failed to obtain source MAC Address : {status}");
        }
      } else {
        Console.WriteLine($"INFO : One MAC Address was already taken.");
      }
    }

    /// <summary>Releases the source MAC address that was previously reserved.</summary>
    void HandleReleaseSourceMacAddress() {
      if (_sourceMac is null) {
        Console.WriteLine("INFO : No MAC Address to release.");
      } else {
        new Xl().NetReleaseMACAddress(_networkHandle, _sourceMac);
        _sourceMac = null;
        Console.WriteLine("INFO : MAC Address has been successfully released.");
      }
    }

    /// <summary>Lets the user set a different destination MAC address.</summary>
    void HandleEnterDestinationMacAddress() {
      Console.WriteLine("Enter destination MAC Address:");
      string answer = Console.ReadLine().Trim();
      try {
        // PhsicalAddress accespts 010203040506 or 01-02-03-04-05-06 but not 01:02:03:04:05:06.
        // To also accept the last syntax replace ':' with '-'. Additionally, PhysicalAddress only
        // accepts upper-case letters. The demo calls ToUpper() to allow lower-case as well.
        _remoteMac = new XlEthMacAddress(PhysicalAddress.Parse(answer.Replace(':','-').ToUpper()));
      } catch (FormatException) {
        Console.WriteLine($"ERROR : Given destination MAC \"{answer}\" has wrong fromat.");
      }
    }

    /// <summary>Lets the user set a different destination IP.</summary>
    void HandleEnterDestinationIpAddress() {
      Console.WriteLine("Enter destination IP Address:");
      string answer = Console.ReadLine().Trim();
      try {
        var ip = IPAddress.Parse(answer);
        if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork) {
          _remoteIp = ip;
        } else {
          Console.WriteLine("ERROR : this demo only implements IPv4 addresses.");
        }
      } catch (FormatException) {
        Console.WriteLine($"ERROR : Given destination IP \"{answer}\" has wrong format.");
      }
    }

    /// <summary>Prints information on the frame that is stored in <see cref="_lastRxFrameReceived"/></summary>
    void HandlePrintLastRxFrameReceived() {
      if (_lastRxFrameReceived.dataLen < Xl.EthPayloadSizeMin + EtherTypeSize) {
        Console.WriteLine("ERROR : No or incomplete frame received.");
        return;
      }
      int payloadSize = _lastRxFrameReceived.dataLen - EtherTypeSize;
      XlArraySliceByte p = _lastRxFrameReceived.frameData_ethFrame_payload;
      Console.WriteLine("Last received frame:");
      Console.WriteLine("----------------------");
      Console.WriteLine($"MAC Src: {_lastRxFrameReceived.sourceMAC}");
      Console.WriteLine($"MAC Dst: {_lastRxFrameReceived.destMAC}");
      Console.WriteLine("----------------------");
      Console.WriteLine($"IP Src: {p[12]}.{p[13]}.{p[14]}.{p[15]}");
      Console.WriteLine($"IP Dst: {p[16]}.{p[17]}.{p[18]}.{p[19]}");
      Console.WriteLine("----------------------");
      Console.WriteLine("Payload:");    
      int udpPayloadStart = IpV4HeaderSize + UdpHeaderSize;
      // find terminating null
      int endOfString = p.IndexOf(0, udpPayloadStart, payloadSize - udpPayloadStart);
      if (endOfString == -1) {
        // if we cannot find a terminating null, stop reading at the end of payloadSize.
        endOfString = payloadSize - udpPayloadStart;
      }
      if (endOfString == udpPayloadStart) {
        Console.WriteLine("<no content>");
      } else {
        // Read the payload into a new array, interpret it as a UTF-8 string and print that string.
        Console.WriteLine(Encoding.UTF8.GetString(p.ToArray(udpPayloadStart, endOfString - udpPayloadStart)));
      }
      Console.WriteLine("----------------------");
    }

    /// <summary>Transmit a single frame on the curently selected MP.</summary>
    void HandleTransmitOnMp() {
      if (_currentMpIdx >= 0) {
        SendSingleFrame(_connectedMPs[_currentMpIdx]);
      } else {
        Console.WriteLine("No connected MPs available.");
      }
    }

    /// <summary>Transmit a single frame on the curently selected VP.</summary>
    void HandleTransmitOnVp() {
      if (_currentVpIdx >= 0) {
        SendSingleFrame(_openVPs[_currentVpIdx]);
      } else {
        Console.WriteLine("No open VPs available");
      }
    }

    /// <summary>Dispatches console input to the handler method for the specific key. </summary>
    void HandleInputEvent(ConsoleKeyInfo keyInfo, ref bool shallQuit) {
      switch (keyInfo.Key) {
        case ConsoleKey.D0:
        case ConsoleKey.NumPad0:
          break;
        case ConsoleKey.D1:  
        case ConsoleKey.D2:
        case ConsoleKey.D3:
        case ConsoleKey.D4:
        case ConsoleKey.D5:
        case ConsoleKey.D6:
        case ConsoleKey.D7:
        case ConsoleKey.D8:
        case ConsoleKey.D9:
        case ConsoleKey.NumPad1:
        case ConsoleKey.NumPad2:
        case ConsoleKey.NumPad3:
        case ConsoleKey.NumPad4:
        case ConsoleKey.NumPad5:
        case ConsoleKey.NumPad6:
        case ConsoleKey.NumPad7:
        case ConsoleKey.NumPad8:
        case ConsoleKey.NumPad9:
          HandleSelectMp(keyInfo.KeyChar - '1');     
          break;
        case ConsoleKey.Add:
        case ConsoleKey.OemPlus:
          HandlePrevNextMp(1);
          break;
        case ConsoleKey.Subtract:
        case ConsoleKey.OemMinus:
          HandlePrevNextMp(-1);
          break;
        case ConsoleKey.Multiply:
          HandlePrevNextVp(1);
          break;
        case ConsoleKey.Divide:
          HandlePrevNextVp(-1);
          break;
        case ConsoleKey.T:
          if ((keyInfo.Modifiers & ConsoleModifiers.Shift) != 0) {
            HandleTransmitOnVp();
          } else {
            HandleTransmitOnMp();
          }
          break;
        case ConsoleKey.S:
          HandleRequestChannelStatus();
          break;
        case ConsoleKey.P:
          HandlePrintLastRxFrameReceived();
          break;
        case ConsoleKey.G:
          HandleRequestSourceMacAddress();
          break;
        case ConsoleKey.R:
          if ((keyInfo.Modifiers & ConsoleModifiers.Shift) != 0) {
            HandleReleaseSourceMacAddress();
          } else {
            HandleResetClocks();
          }
          break;
        case ConsoleKey.M:
          HandleEnterDestinationMacAddress();
          break;
        case ConsoleKey.I:
          HandleEnterDestinationIpAddress();
          break;
        case ConsoleKey.W:
          ShowDriverConfig();
          break;
        case ConsoleKey.H:
          ShowMenuHelp();
          break;
        case ConsoleKey.Escape:
        case ConsoleKey.Q:
          shallQuit = true;
          break;
        default:
          Console.WriteLine("Unknown command");
          break;
      }
    }

    /// <summary>Writes a line of output for every event received.</summary>
    void HandleXlApiEvent(XlNetEthEvent rxEvent, int rxHandleCount, XlRxHandle[] rxHandles) {
      if ((rxEvent.flagsChip & XlEthFlagsChip.QueueOverflow) != 0) {
        Console.WriteLine("Event receive: Overflow!");
      }

      StringBuilder sb = new StringBuilder($"Received {rxEvent.tag} ");
      switch (rxEvent.tag) {
        case XlEthEventTag.FramerxSimulation:
          rxEvent.tagData_frameSimRx.CopyTo(_lastRxFrameReceived);
          break;
        case XlEthEventTag.FramerxMeasurement:
          rxEvent.tagData_frameMeasureRx.CopyTo(_lastRxFrameReceived);
          break;
        case XlEthEventTag.FramerxErrorSimulation:
          sb.Append($"{rxEvent.tagData_frameSimRxError_errorFlags.Rx} ");
          break;
        case XlEthEventTag.FramerxErrorMeasurement:
          sb.Append($"{rxEvent.tagData_frameMeasureRxError_errorFlags.Rx} ");
          break;
        case XlEthEventTag.FrametxErrorSimulation:
          sb.Append($"{rxEvent.tagData_frameSimTxError_errorFlags.Tx} ");
          break;
        case XlEthEventTag.FrametxErrorMeasurement:
          sb.Append($"{rxEvent.tagData_frameMeasureTx_errorFlags.Tx} ");
          break;
        case XlEthEventTag.ChannelStatus:
          sb.Append($"{rxEvent.tagData_channelStatus_link} ");
          break;
      }

      if (rxHandleCount > 0) {
        sb.Append("on ");
        for (int i = 0; i < rxHandleCount; ++i) {
          sb.Append(_rxHandleMap[rxHandles[i]].Name);
          if (i + 1 < rxHandleCount) {
            sb.Append(',');
          }
        }
      }
      Console.WriteLine(sb);
    }

    /// <summary>The main loop handles both incoming XLAPI events and keyboard input.</summary>
    void MainLoop() {
      var xl = new Xl();
      bool shallQuit = false;
      // For efficiency, reuse the same rxEvent and rxHandles buffer for every event received.
      var rxEvent = new XlNetEthEvent();
      var rxHandles = new XlRxHandle[_rxHandleMap.Count];
      uint rxHandleCount;

      while (true) {
        bool anyProgress = false;
        if (Console.KeyAvailable) {
          HandleInputEvent(Console.ReadKey(true), ref shallQuit);
          anyProgress = true;
          if (shallQuit) {
            return;
          }
        }
        var status = xl.TryNetEthReceive(_networkHandle, rxEvent, out rxHandleCount, rxHandles);
        if (status == XlStatus.Success) {
          HandleXlApiEvent(rxEvent, (int)rxHandleCount, rxHandles);
          anyProgress = true;
        } else if (status != XlStatus.ErrQueueIsEmpty) {
          //  XlStatus.ErrQueueIsEmpty is normal, but any other return code is a problem.
          Console.WriteLine($"ERROR: TryNetEthReceive returned: {status}");
          return;
        }
        if (!anyProgress) {
          // If neither keyboard input nor an XLAPI-Event is available, wait for the next event but wakeup
          // after at most 500 ms, to check for new keyboard input.
          _notifyEvent.WaitOne(500);
        }
      }
    }

    /// <summary>Main logic of the demo.</summary>
    void RunDemo() {
      Console.WriteLine("------------------------------------------------------------");
      Console.WriteLine("-              xlNetEthDemo_Csharp  V25.20                 -");
      Console.WriteLine("-            (C) 2025 Vector Informatik GmbH               -");
      Console.WriteLine("------------------------------------------------------------");
      // Print the version of the .NEt Wrapper.
      Console.WriteLine($"Vector.XlApi.dll:    {typeof(Xl).Assembly.GetName().Version,12}");

      // Create an Xl-Instance. The first Xl-Instance created internally calls xlOpenDriver. The application
      // does not need to call xlCloseDriver. The Xl-Object itself is stateless.
      var xl = new Xl();

      // Get the current state of the XL driver configuration. Note the 'using' directive to ensure that
      // the native memory is immediately disposed. The rest of this demo only needs the managed representation
      // of the driver configuration.
      using (var driverConfig = xl.CreateDriverConfig()) {
        // Print the version number of the native library.
        Console.WriteLine($"{$"{Xl.NativeLibraryName}:",-20} {driverConfig.GetDllConfig().dllVersion,12}");
        // Get managed representation of devices and networks.
        _devices = driverConfig.GetDeviceConfig();
        _networks = NetworkWithIndex.Enumerate(driverConfig.GetNetworkConfig()).ToList();
      }

      // List all devices found by XL-API.
      Console.WriteLine($"Found {_devices.Count} devices");
      for (int deviceIndx = 0; deviceIndx < _devices.Count; ++deviceIndx) {
        var device = _devices[deviceIndx];
        Console.WriteLine($"[{deviceIndx}] Found {device.name}:{device.hwIndex + 1}({device.serialNumber:D6}) device");
      }

      if (_networks.Count((n) => n.NetworkConfig.networkType == XlNetworkType.Eth) > 0) {
        // Print set of available networks and let the user choose the network for this demo.
        ShowNetworks(_networks);
        _selectedNetwork = ChooseNetwork();
        if (_selectedNetwork is null) {
          // user pressed escape.
          return;
        }
      } else {
        AbortDemoDueToMissingNetwork();
        return; 
      }

      // Show the selected network again and let the user select a switch to add a virtual port on.
      ShowNetworks(new[] { _selectedNetwork });
      _segmentToAddVpOn = ChooseSegmentForAddVp();

      // Open the network with an 8 MB receive queue.
      _networkHandle = xl.NetEthOpenNetwork(_selectedNetwork.NetworkConfig.networkName, "xlNetEthDemo_Csharp", XlAccessType.Reliable, 8 << 20);

      // Call xlNetAddVirtualPort, xlNetOpenVirtualPort and/or xlNetConnectMeasurementPoint. At least one port must be opened.
      AddOpenOrConnectVPandMP();
      if (_rxHandleMap.Count == 0) {
        AbortDemoDueToMissingPorts();
        return;
      }

      // Request a notification at queueLevel=1 byte.
      _notifyEvent = xl.NetSetNotification(_networkHandle, 1);

      // Activate network (start receiving events)
      xl.NetActivateNetwork(_networkHandle);
      _networkActivated = true;

      Console.Write("\nINFO : Initialization finished. Press any key to continue demo...");
      Console.ReadKey(true);

      // Print even more information...
      ShowSettings();
      ShowDriverConfig();
      ShowMenuHelp();

      // Enter the main loop
      MainLoop();
    }

    /// <summary>Performs cleanup of driver resources, both on regular exit and on error.</summary>
    void CleanupDemo() {
      // It would be sufficient to just close the network, as deactivation and release of MAC addresses will
      // happen implicitly, but for clarity, the demo cleans up step-by-step.
      var xl = new Xl();

      if (!(_sourceMac is null)) {
        xl.NetReleaseMACAddress(_networkHandle, _sourceMac);
        _sourceMac = null;
      }

      if (_networkActivated) {
        xl.NetDeactivateNetwork(_networkHandle);
        _networkActivated = false;
      }

      if (_networkHandle != XlNetworkHandle.Invalid) {
        xl.NetCloseNetwork(_networkHandle);
        _networkHandle = XlNetworkHandle.Invalid;
      }
    }

    /// <summary>Entry point of the application</summary>
    static void Main(string[] args) {
      var program = new Program();
      try {
        program.RunDemo();
      } catch (Exception e) {
        Console.WriteLine(e);
        Console.WriteLine("Press any key to quit.");
        Console.ReadKey(true);
      } finally {
        program.CleanupDemo();
      }
    }
  }
}
